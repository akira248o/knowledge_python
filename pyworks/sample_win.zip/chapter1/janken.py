import random
data = ['goo','choki','pa']
data_choice = random.choice(data)
print(data_choice)
