import turtle

class Kame(turtle.Turtle):
	def __init__(self):
		super(Kame,self).__init__()
		self.shape('turtle')
		self.shapesize(2,2)
