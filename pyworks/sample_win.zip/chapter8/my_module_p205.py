def func(v):
	i = v * 3
	return i
