import sys

input_list = sys.argv[1:]
input_list.sort()
print(input_list)

